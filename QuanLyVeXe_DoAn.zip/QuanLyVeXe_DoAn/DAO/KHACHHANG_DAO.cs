﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DTO;

namespace DAO
    {
        // Gọi từ DTO
        public class KHACHHANG_DAO
        {
            static SqlConnection conn;
            public static List<KHACHHANG_DTO> LoadKHACHHANG()
            {
                string query = @"select * from KhachHang";
                conn = DataProvider.KetNoi();
                DataTable dt = DataProvider.LayDataTable(query, conn);
                if (dt.Rows.Count == 0)
                {
                    return null;
                }
                List<KHACHHANG_DTO> lstkhachhang = new List<KHACHHANG_DTO>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    KHACHHANG_DTO ode = new KHACHHANG_DTO();
                    ode.ID = dt.Rows[i]["ID_KhachHang"].ToString();
                    ode.HoTen = dt.Rows[i]["HoTen"].ToString();
                    ode.SDT = dt.Rows[i]["DienThoai"].ToString();
                    
           
                    ode.Email = dt.Rows[i]["Email"].ToString();
                    ode.Loai = dt.Rows[i]["Loai"].ToString();
 
                    lstkhachhang.Add(ode);
                }
                DataProvider.DongKetNoi(conn);
                return lstkhachhang;
            }

            public static bool AddKHACHHANG(KHACHHANG_DTO kh)
            {
                string query = string.Format("Insert Into KhachHang (ID_KhachHang, HoTen, DienThoai, Email, Loai) values (N'{0}', N'{1}', N'{2}', '{3}', N'{4}')",
                                             kh.ID, kh.HoTen, kh.SDT,  kh.Email, kh.Loai);
                conn = DataProvider.KetNoi();
                try
                {
                    DataProvider.ThucThiQuery(query, conn);
                    DataProvider.DongKetNoi(conn);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }

            }
            public static bool EditKHACHHANG(KHACHHANG_DTO kh)
            {
                string query = string.Format("UPDATE KhachHang set  HoTen=N'{0}', DienThoai=N'{1}', Email=N'{2}', Loai=N'{3}',  where ID_KhachHang=N'{4}' ",
                                              kh.HoTen, kh.SDT,  kh.Email, kh.Loai, kh.ID);

                conn = DataProvider.KetNoi();
                try
                {
                    DataProvider.ThucThiQuery(query, conn);
                    DataProvider.DongKetNoi(conn);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }

            }
            public static bool XoaKHACHHANG(KHACHHANG_DTO kh)
            {
                string query = string.Format("DELETE FROM KhachHang Where ID_KhachHang = N'{0}'", kh.ID);
                conn = DataProvider.KetNoi();
                try
                {
                    DataProvider.ThucThiQuery(query, conn);
                    DataProvider.DongKetNoi(conn);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

    }


