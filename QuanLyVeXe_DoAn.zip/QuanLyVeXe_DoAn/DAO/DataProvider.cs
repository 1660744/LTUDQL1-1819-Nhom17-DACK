﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAO
{
    public class DataProvider
    {
        public static SqlConnection KetNoi()
        {
            string connectionString = @"Data Source=DESKTOP-L273NPT;Initial Catalog=qlvx;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            return conn;
        }
        public static void DongKetNoi(SqlConnection conn)
        {
            conn.Close();
        }
        public static DataTable LayDataTable(string query, SqlConnection conn)
        {
            SqlDataAdapter sqlda = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            return dt;
        }
        public static bool ThucThiQuery(string query, SqlConnection conn)
        {
            try
            {
                SqlCommand sqlcom = new SqlCommand(query, conn);
                sqlcom.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
