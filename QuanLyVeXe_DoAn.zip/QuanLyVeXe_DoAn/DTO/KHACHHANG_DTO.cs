﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
   public class KHACHHANG_DTO
    {
        private string iD;

        public string ID { get => iD; set => iD = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public string SDT { get => sDT; set => sDT = value; }
        public string Email { get => email; set => email = value; }
        public string Loai { get => loai; set => loai = value; }

       
        private string hoTen;// viết dòng này như vậy sao đó bấm crlt +R_E , ĐỂ xuất hiện :public string HoTen { get => hoTen; set => hoTen = value; } 
        //
        private string sDT;
        private string email;
        private string loai;
    }
}
