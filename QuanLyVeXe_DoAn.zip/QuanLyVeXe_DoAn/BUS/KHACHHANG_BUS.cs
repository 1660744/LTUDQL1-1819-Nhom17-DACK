﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAO;

namespace BUS
{
    public class KHACHHANG_BUS
    {
        public static List<KHACHHANG_DTO> LoadKHACHHANG()
        {
            return KHACHHANG_DAO.LoadKHACHHANG();
        }

        public static bool AddKHACHHANG(KHACHHANG_DTO kh)
        {
            return KHACHHANG_DAO.AddKHACHHANG(kh);
        }

        public static bool EditKHACHHANG(KHACHHANG_DTO kh)
        {
            return KHACHHANG_DAO.EditKHACHHANG(kh);
        }

        public static bool XoaKHACHHANG(KHACHHANG_DTO kh)
        {
            return KHACHHANG_DAO.XoaKHACHHANG(kh);
        }
    }
}
