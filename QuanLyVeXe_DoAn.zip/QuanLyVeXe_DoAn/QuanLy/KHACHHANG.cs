﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using BUS;
namespace QuanLy
{
    public partial class KHACHHANG : Form
    {
        public KHACHHANG()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        private void KHACHHANG_Load(object sender, EventArgs e)
        {
            LoadData_KHACHHANG(); // load dữ liệu từ bảng tài khoản trog Danh sách Khách hàng
        }
        private void LoadData_KHACHHANG()
        {
            List<KHACHHANG_DTO> lstkhachhang = KHACHHANG_BUS.LoadKHACHHANG();
            dataGridView1.DataSource = lstkhachhang;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            KHACHHANG_DTO Khachhang = new KHACHHANG_DTO();
            AddDataInTextBox(Khachhang);
            if (KHACHHANG_BUS.XoaKHACHHANG(Khachhang) == true && KiemTraDuLieu() == true)
            {
                LoadData_KHACHHANG();
                MessageBox.Show("Xoa thanh cong");
                return;
            }
            MessageBox.Show("that bai");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dr = dataGridView1.SelectedRows[0];
            txtID.Text = dr.Cells["ID_KhachHang"].Value.ToString();
            txtHoTen.Text = dr.Cells["HoTen"].Value.ToString();
            txtSDT.Text = dr.Cells["DienThoai"].Value.ToString();
            txtEmail.Text = dr.Cells["Email"].Value.ToString();
            txtLoai.Text = dr.Cells["Loai"].Value.ToString();

        }

        private bool KiemTraDuLieu()
        {
            if (txtID.Text.Length <= 0 || txtHoTen.Text.Length <= 0 || txtSDT.Text.Length <= 0
                || txtEmail.Text.Length <= 0 || txtLoai.Text.Length <= 0)
            {
                return false;
            }
            else
                return true;
        }

        private void AddDataInTextBox(KHACHHANG_DTO Khachhang)//khi bấm vào dataggidieww hiện dữ liệu lên text box
         {
            Khachhang.ID = txtID.Text;
            Khachhang.HoTen = txtHoTen.Text;
            Khachhang.SDT = txtSDT.Text;
            Khachhang.Email = txtEmail.Text;
            Khachhang.Loai = txtLoai.Text;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            KHACHHANG_DTO Khachhang = new KHACHHANG_DTO();
            AddDataInTextBox(Khachhang);
            if (KHACHHANG_BUS.AddKHACHHANG(Khachhang) == true && KiemTraDuLieu() == true)
            {
                LoadData_KHACHHANG();
                MessageBox.Show("Them thanh cong");
                return;
            }
            else if (KiemTraDuLieu() == false)
            {
                MessageBox.Show("Du lieu them vao khong duoc de trong!!!");
            }
            if (KHACHHANG_BUS.AddKHACHHANG(Khachhang) == false)
            {
                MessageBox.Show("Vi phaM rang buoc CSDL, them that bai!!!");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            KHACHHANG_DTO Khachhang = new KHACHHANG_DTO();
            AddDataInTextBox(Khachhang);
            if (KHACHHANG_BUS.EditKHACHHANG(Khachhang) == true && KiemTraDuLieu() == true)
            {
                LoadData_KHACHHANG();
                MessageBox.Show("Edit thanh cong");
                return;
            }
            MessageBox.Show("that bai");
        }

        private void KHACHHANG_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qlvxDataSet.KhachHang' table. You can move, or remove it, as needed.
          //  this.khachHangTableAdapter.Fill(this.qlvxDataSet.KhachHang);

            LoadData_KHACHHANG();//load từ csdl lên
        }
    }
}
